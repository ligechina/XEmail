@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
if not exist ".venv" (
  py -3 -m venv .venv
  if errorlevel 1 (
    echo [ERROR] Failed to create virtual environment. Please install Python 3 first.
    exit /b 1
  )
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo [ERROR] Dependency installation failed.
  exit /b 1
)
echo [OK] Installation completed.
echo Run scripts\start_windows.bat to start XEmail.
exit /b 0
