XEmail Windows Installation

1) Install Python 3.10+ and ensure "py" command works.
2) Double click install_windows.bat (or run in CMD).
3) Start service with scripts\\start_windows.bat
4) Open browser at http://127.0.0.1:8000
