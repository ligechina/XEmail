@echo off
echo Press Ctrl+C in the running terminal to stop XEmail.
