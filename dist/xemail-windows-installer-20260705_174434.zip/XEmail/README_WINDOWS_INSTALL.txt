XEmail Windows 安装说明
=======================

1) 双击运行 install_windows.bat
2) 等待依赖安装完成
3) 打开浏览器访问 http://127.0.0.1:8000

停止服务：
- 运行 scripts\stop_windows.bat
