@echo off
setlocal
set "APP_DIR=%~dp0"
cd /d "%APP_DIR%"
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
)
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
start "" cmd /c "call scripts\start_windows.bat"
echo.
echo XEmail 已安装并尝试启动。
echo 首次打开请访问 http://127.0.0.1:8000
pause
