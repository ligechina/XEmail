@echo off
setlocal
set "APP_DIR=%~dp0.."
cd /d "%APP_DIR%"
if exist ".venv\Scripts\activate.bat" call ".venv\Scripts\activate.bat"
start "" python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
