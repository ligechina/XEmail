@echo off
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":8000" ^| findstr LISTENING') do taskkill /PID %%a /F >nul 2>nul
echo XEmail 后端已尝试停止（端口 8000）。
